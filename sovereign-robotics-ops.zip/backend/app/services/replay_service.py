from __future__ import annotations

# MVP placeholder for richer replay features:
# - export telemetry timeline
# - reconstruct states
# - attach artifacts/video
