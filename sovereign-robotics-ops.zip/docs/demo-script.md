# Demo Script (2–3 minutes)

1) Create mission “Deliver to Bay 3” with goal (x=15,y=7)
2) Start run
3) Watch:
   - First proposal uses speed 0.8 (near human/obstacle) → denied by governance
   - Second proposal uses speed 0.4 → approved
4) Open Policies → Test Action:
   - Submit MOVE_TO with high speed and low clearance → see deny reasons
5) Emphasize:
   - “Governance as computation”
   - “Audit-ready chain-of-trust timeline”
