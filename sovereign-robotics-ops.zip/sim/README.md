# Simulation

For MVP speed, we provide a mock simulator that behaves like a tiny robotics runtime:
- streams telemetry
- accepts commands
- updates robot position over time

Later you can replace this with Webots / Isaac Sim / Gazebo via a ROS2 or HTTP bridge.
